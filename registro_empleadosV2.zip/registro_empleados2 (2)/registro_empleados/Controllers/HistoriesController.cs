
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using registro_empleados.Data;
/*
using System.Security.Cryptography;
*/

namespace registro_empleados.Controllers
{
  public class HistoriesController : Controller{

    public readonly BaseContext _context;
    public HistoriesController(BaseContext context){
      _context = context;
    }
    public async Task<IActionResult> Index()
    {
      return View(await _context.Histories.ToListAsync());
    }

      public async Task<IActionResult> Delete(int? Id)
        {
            var employ = await _context.Histories.FindAsync(Id);
            _context.Histories.Remove(employ);
            await _context.SaveChangesAsync();
            return RedirectToAction("Index");
        } 

     

    
  }
}

