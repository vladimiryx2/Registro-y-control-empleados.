using Microsoft.AspNetCore.Mvc;
using registro_empleados.Data;
using Microsoft.EntityFrameworkCore;
using registro_empleados.Models;
using System.Text;
using System.Security.Cryptography;

namespace registro_empleados.Controllers
{
    public class AuthController: Controller
    {
        public readonly BaseContext _context;
        public AuthController(BaseContext context){
            _context = context;
        }

        public   IActionResult Index(){
            return View();
        }
        [HttpPost]
        public  async Task<IActionResult> Login(string Identification, string Password)
        {
            var pass =  ConvertirSha256(Password);

            var userLogin = await _context.Employees.FirstOrDefaultAsync(em => em.Identification == Identification);
            if(userLogin != null && userLogin.Password == pass)
            {
                HttpContext.Session.SetString("Names", userLogin.Names);
                HttpContext.Session.SetInt32("Id", userLogin.Id);//variable de sesion
                  return RedirectToAction("Index", "Employees");
            } else {
            return RedirectToAction("Index");
            }
            
        }

            public IActionResult Register(){
                return View();
            }

    [HttpPost]
    public IActionResult Register(Employee c){


      if(c.Password == c.Confirmation_password )
      {
        c.Password = ConvertirSha256(c.Password);
      } else {
         ViewData["Mensaje"] = "Credenciales incorrectos";
      }
      _context.Employees.Add(c);
      _context.SaveChanges();
      return RedirectToAction("Index");
    }

    public static string ConvertirSha256(string texto)
    {
      StringBuilder Sb = new StringBuilder();
      using(SHA256 hash = SHA256Managed.Create())
      { 
        Encoding enc = Encoding.UTF8;
        byte[] result = hash.ComputeHash(enc.GetBytes(texto));
        foreach(byte b in result)
            Sb.Append(b.ToString("x2"));
      }
      return Sb.ToString();
    }

    }
}