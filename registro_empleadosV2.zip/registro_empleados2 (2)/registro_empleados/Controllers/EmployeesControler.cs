using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using registro_empleados.Data;
using registro_empleados.Models;
using System.Data;
using System.Text;


namespace registro_empleados.Controllers{
  public class EmployeesController : Controller{

    public readonly BaseContext _context;
    public EmployeesController(BaseContext context){
      _context = context;
    }
    public async Task<IActionResult> Index(){
      ViewBag.Names = HttpContext.Session.GetString("Names");
      ViewBag.Id = HttpContext.Session.GetInt32("Id");
      ViewBag.Enter = await _context.Histories.FirstOrDefaultAsync(h => h.Id_employee == HttpContext.Session.GetInt32("Id") && h.Coming_out == null);
      if(ViewBag.Names == null){
        return RedirectToAction("Index", "Auth");
       
      }
       return View("Index");
      
    }

  public  IActionResult Logout(){
      HttpContext.Session.Remove("Names");
       return RedirectToAction("Index","Auth");
    }
    
    public async Task<IActionResult> Entries()
    {
      
        var Id_employee = HttpContext.Session.GetInt32("Id");
    
                var history = new History(){
                    Entrance =   DateTime.Now,
                    Id_employee = Id_employee
                    
                };
                _context.Histories.Add(history);
                await _context.SaveChangesAsync();
              return RedirectToAction("Index");
        
    }

    public async Task<IActionResult> Coming_out(){
            try
            {
               var Exit = await _context.Histories.FirstOrDefaultAsync(r => r.Id_employee == HttpContext.Session.GetInt32("Id") && r.Coming_out == null);
               Exit.Coming_out = DateTime.Now;
               await _context.SaveChangesAsync();
               TempData["MessageSuccess"] = "Se ha generado el registro de tu salida correctamente"; 
               return RedirectToAction("Index");  

            }
            catch (System.Exception)
            {
                // aqui mensaje a slack mediante webhook
                throw;
            }
    }


    public IActionResult Enter(){
      return View();
    
    }

    



   /* public bool Login(string user, string pass)
  {
    using (var connection = GetConnection())
    {
      connection.Open();
      using (var command = new MySqlCommand())
      {
        command.Connection = connection;
        command.CommandText = "select *from users where (loginName=@user and password=@pass) or (Email=@user and password=@pass)";
        command.Parameters.AddWithValue("@user", user);
        command.Parameters.AddWithValue("@pass", pass);
        command.CommandType = CommandType.Text;
        MySqlDataReader reader = command.ExecuteReader();
        if (reader.HasRows)
        {
       
          return true;
        }
        else
          return false;
      }
    }
  }*/


  }
}

