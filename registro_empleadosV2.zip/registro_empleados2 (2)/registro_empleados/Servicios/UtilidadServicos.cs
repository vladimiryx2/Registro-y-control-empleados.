namespace registro_empleados.Servicios
{
    public class UtilidadServicios{

    }
}