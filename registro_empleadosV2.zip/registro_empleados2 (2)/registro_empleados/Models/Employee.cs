namespace registro_empleados.Models{
    public class Employee{

        public int Id { get; set; } 
        public string? Names { get; set; } 
        public string? LastNames { get; set; } 
        public string? Email { get; set; }
        public string? Identification { get; set; } 
        public string? Password { get; set; } 
        public string? Confirmation_password { get; set; } 

    }
}


