namespace registro_empleados.Models{
    public class History{

        public int Id { get; set; } 
        public string? Range_Time { get; set; } 
        public int? Id_employee { get; set; } 
        public DateTime Entrance { get; set; }
        public DateTime? Coming_out { get; set; } 
    }
}   