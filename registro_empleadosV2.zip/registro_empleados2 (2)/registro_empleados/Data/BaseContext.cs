using Microsoft.EntityFrameworkCore;
using registro_empleados.Models;

namespace registro_empleados.Data
{
    public class BaseContext : DbContext
    {
        public BaseContext(DbContextOptions<BaseContext> options): base(options){

        }
        public DbSet <Employee> Employees { get; set; }
        public DbSet <History> Histories { get; set; }
    }
}
   
